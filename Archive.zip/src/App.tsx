import React from 'react';
import './App.css';
import AutoComplete from './components/Autocomplete/AutoComplete';

function App() {
  return (
    <div className="App">
      <AutoComplete />
    </div>
  );
}

export default App;
