To run this application -

### `npm start`

installs all the dependencies required for this project.

### `npm start`

Runs the app in the development mode.
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

### `npm test`

Executes all the tests.

Notes
Ensure you have the latest versions of Node.js and npm for a smooth experience.
The application uses custom hooks like useDebounce and useFetch to handle asynchronous data fetching with debouncing.